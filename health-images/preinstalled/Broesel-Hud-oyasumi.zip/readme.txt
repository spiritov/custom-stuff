extract this into broeselhud (replace all files)

oyasumi (health image) by mur
https://github.com/spiritov/custom-stuff
