ascii-faces (health image) by mur
https://github.com/spiritov/custom-stuff